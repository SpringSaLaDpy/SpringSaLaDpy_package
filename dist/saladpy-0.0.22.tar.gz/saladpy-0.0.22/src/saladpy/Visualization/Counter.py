from .MoleculeCounter import *
from .Molclustpy_visualization_funcitons import *
from saladpy.display_info import *
from saladpy.data_locator import *

def plot(search_directory, indicies=[]):
    # Compute the free molecular concentrations
    mc = MoleculeCounter(search_directory)
    mc.getMoleculeStat()

    example = data_file_finder(search_directory, search_term="FullState", path_list=['data', 'Run0'])
    title = os.path.split(example)[1][:-4]
    column_info(example, start_col=1)

    plotTimeCourseCopy(search_directory, title, indicies)